import redis
import requests
Token="1494641035:AAH2aS7_4VlnqABHsJ9x0bZ3pWqvkAAHDqw"
TgImages="https://api.telegram.org/file/bot1494641035:AAH2aS7_4VlnqABHsJ9x0bZ3pWqvkAAHDqw/"
images="images/"

class postcards:
    def __init__(self):
        self.drawer = redis.Redis()
        self.drawer.set("postcards", "")

    def drop(self):
        self.drawer.set("postcards", "")

    def addPostcard(self, file_id):
        data=self.drawer.get("postcards")
        data=data.decode("utf-8")
        data+=" "+str(file_id)
        self.drawer.set("postcards", data)
        return True

    def getPostcards(self):
        data = self.drawer.get("postcards")
        data = data.decode("utf-8")
        data=data.split(" ")
        return data


def tg_dl_file(fileName):
    URLlink = TgImages + fileName
    DownloadedFileName = fileName[fileName.rfind("/") + 1:]
    req = requests.get(URLlink)
    with requests.get(URLlink) as req:
        with open(DownloadedFileName, "wb") as f:
            for chunk in req.iter_content(chunk_size=4096):
                if chunk:
                    f.write(chunk)

    return DownloadedFileName
import telebot
import functional
from random import choice
import os

bot=telebot.TeleBot(functional.Token, threaded=False)
files=functional.postcards()

@bot.message_handler(commands=["add"])
def addCommand(message):
    global files
    user_replied_to=message.reply_to_message
    if user_replied_to.content_type=="photo":
        print("got add")
        fileName = bot.get_file(user_replied_to.json["photo"][0]["file_id"]).file_path
        functional.tg_dl_file(fileName)
        file_id=user_replied_to.json["photo"][0]["file_unique_id"]
        try:
            files.addPostcard(file_id)
            bot.send_message(message.chat.id, "Added photo to postcards",
                             reply_to_message_id=message.reply_to_message.message_id)
        except Exception as e:
            print(e)
            bot.send_message(message.chat.id, "oops, something went wrong")

@bot.message_handler(commands=["send"])
def sendCommand(message):
    if message.chat.type=="private":
        exrpessions=open("expressions/text.txt", "rt").readlines()
        exrpession=choice(exrpessions)
        bot.send_message(message.chat.id, exrpession)
    else:
        print(message.chat.id)
        global files
        greetings=open("expressions/captions.txt", "rt").readlines()
        id = message.chat.id
        try:
            pass
        except Exception as e:
            print(e)
        postcards=files.getPostcards()
        for postcard in postcards:
            try:
                bot.send_photo(message.chat.id, postcard, caption=choice(greetings))
            except Exception as exc:
                print(exc)
        counter = 0
        for file in os.listdir():
            if counter == 3:
                break
            if file[file.rfind(".") + 1:].lower() == "jpg" or file[file.rfind(".") + 1:].lower() == "jpeg" or file[file.rfind(".") + 1:].lower() == "png":
                with open(file, "rb") as f:
                    data = f.read()
                    bot.send_photo(id, data, caption=choice(greetings))
                f.close()
                os.remove(file)
                print("photos removed, storage empty")

@bot.message_handler(commands=["drop"])
def dropCommand(message):
   global files
   files.drop()
   bot.send_message(message.chat.id, "DB flushd", reply_to_message_id=message.message_id)

if __name__=="__main__":
    print("bot online")
    bot.infinity_polling()
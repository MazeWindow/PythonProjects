import os
import telebot
import functional

bot=telebot.TeleBot(functional.Token, threaded=False)

counter=0
data=[]
for file in os.listdir():
    if counter == 3:
        break
    if file[file.rfind(".") + 1:].lower() == "jpg" or file[file.rfind(".") + 1:].lower() == "jpeg" or file[file.rfind(".") + 1:].lower() == "png":
        with open(file, "rb") as f:
            data=f.read()
            bot.send_photo(-359782299, data)
        f.close()

        # os.remove(file)

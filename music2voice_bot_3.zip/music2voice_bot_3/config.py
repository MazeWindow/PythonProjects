TOKEN="1452244142:AAGQM4OEbX8D2bm_utrbdpMvFXfrUijC9WU"
SERVER_FILES_DIR="https://api.telegram.org/file/bot"+TOKEN+"/"
LOCAL_MP3_DIR="music/"
LOCAL_OPUS_DIR="opus/"
TIMING_DELIMITERS_ROAM=["-", ",", ";", " "]
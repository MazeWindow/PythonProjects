import config
import telebot
import bioinf
import os
import utils

bot=telebot.TeleBot(config.token, threaded=False)
client=utils.setup_db()

@bot.message_handler(commands=['start'])
def FirstMessageHandler(message):
    bot.send_message(message.chat.id, "Hi, I`m bioinformatics educational bot\n"
                                      "use help for more info")


@bot.message_handler(commands=['help'])
def HelpHandler(message):
    text="Send me fasta-file containing multiple aligned protein sequences\n" \
         "to get summary and evolutional distances matrix"
    bot.send_message(message.chat.id, text)

@bot.message_handler(content_types="document")
def ReportHandler(message):
    global client
    try:
        utils.put_user_in_recent(client, message.from_user.user_id)
    except Exception as e:
        print(e)
    print("getting file")
    filePath=bot.get_file(message.document.file_id).file_path
    fileName=utils.download_file(config.server_files+filePath, filePath[filePath.rfind("/")+1:])
    print("assigning data")
    newData=bioinf.newData(fileName)
    print("saving report")
    reportName=newData.saveReport("automatized_")
    print("report name: ", reportName)
    f = open(reportName, "rt")
    data=f.read()
    try:
        bot.send_document(message.chat.id, f)
    except Exception as e:
        print("failed to send report as file, sending as text")
        bot.send_message(message.chat.id, data)
    f.close()
    os.remove(reportName)
    os.remove(fileName)


if __name__ == '__main__':
     print("bot running")
     bot.infinity_polling()
import requests
import redis

#redis setup and CRUD
def setup_db(n=5):
    try:
        db=redis.Redis()
        db.set("last_user_id",0)
        db.set({"user_ids": [0 for i in range(n)]})
        return db
    except Exception as e:
        print(e)
        return False

def put_user_in_recent(db, user_id):
    try:
        last_id=db.get("last_user_id")
        user_ids=db.get("user_ids")
        user_ids[last_id]=user_id
        db.delete("user_ids")
        db.set({"user_ids":user_ids})
        return True
    except Exception as e:
        print(e)
        return False

def del_user_from_recent(db, user_id):
    try:
        user_ids = db.get("user_ids")
        user_ids.remove(user_id)
        user_ids.append(0)
        db.delete("user_ids")
        db.set({"user_ids": user_ids})
        return True
    except Exception as e:
        print(e)
        return None

def upd_user_from_recent(db, old_id, new_id):
    try:
        user_ids = db.get("user_ids")
        user_idx=user_ids.index(old_id)
        user_ids[user_idx]=new_id
        db.delete("user_ids")
        db.set({"user_ids":user_ids})
        return True
    except Exception as e:
        print(e)
        return False

def get_all_from_recent(db):
    try:
        return db.get("user_ids")
    except Exception as e:
        print(e)
        return None

def download_file(link, filename=""):
    try:
        if filename:
            pass
        else:
            req = requests.get(link)
            filename = req.url[link.rfind("/") + 1:]

        with requests.get(link) as req:
            with open(filename, "wb") as f:
                for chunk in req.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            return filename
    except Exception as e:
        print(e)
        return None
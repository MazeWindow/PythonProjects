token="1501994070:AAGjkzz6_7jGMqCuAV9J7_FetjzKbpYuvl4"
server_files="https://api.telegram.org/file/bot"+token+"/"
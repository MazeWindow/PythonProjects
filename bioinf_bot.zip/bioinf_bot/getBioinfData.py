class fastaEntry:
    def __init__(self, pId, pName, pSpecies, seq):
        self.proteinId = pId
        self.proteinName = pName
        self.proteinSpecies = pSpecies
        self.proteinSequence = seq


class extractFromFasta:
    def readfile(filename):
        with open(filename, "rt") as f:
            newData=f.read()
        return newData

    def catStr(arr):
        sum=""
        for item in arr:
            sum+=item
        return sum

    def exportReport(self):
        data="Protein data:"+"\n"
        data+=self.outStrData()+"\n"
        return data

    def findBetweenBrackets(someString):
        specNameStart=someString.find("[")+1
        specNameEnd=someString.find("]")
        return specNameStart, specNameEnd

    def splitEntry(rawEntry):
        lines=rawEntry.split("\n")

        sequence=extractFromFasta.catStr(lines[1:])

        specNameStart, specNameEnd = extractFromFasta.findBetweenBrackets(lines[0])
        speciesName = lines[0][specNameStart:specNameEnd]

        proteinIdStart, proteinIdEnd = 0, lines[0].find(" ")
        proteinId = lines[0][proteinIdStart:proteinIdEnd]

        proteinNameStart, proteinNameEnd = proteinIdEnd + 1, specNameStart - 2
        proteinName = lines[0][proteinNameStart:proteinNameEnd]

        return proteinId, proteinName, speciesName, sequence

    def splitEntries(someFastaData):
        rawEntries=someFastaData.split(">")
        entriesNum=len(rawEntries)
        prepEntries=[]
        for idx in range(entriesNum):
            interstageRes=extractFromFasta.splitEntry(rawEntries[idx])
            prepEntries.append([interstageRes[0],interstageRes[1],interstageRes[2],interstageRes[3]])

        return prepEntries

    def __init__(self, fileName):
        rawData=extractFromFasta.readfile(fileName)
        fastaEntriesArr=extractFromFasta.splitEntries(rawData)
        dataArr=[]
        for idx in range(0,len(fastaEntriesArr)):
            dataArr.append(fastaEntry(fastaEntriesArr[idx][0], fastaEntriesArr[idx][1], fastaEntriesArr[idx][2], fastaEntriesArr[idx][3]))

        self.AllFastaEntries=dataArr

    def outStrData(self):
        idWidth=[]
        nameWidth=[]
        specWidth=[]
        dataToOut=""
        seqWidth=[20, len("Protein sequence")]
        for i in range(len(self.AllFastaEntries)):
            idWidth.append(len(self.AllFastaEntries[i].proteinId))
            nameWidth.append(len(self.AllFastaEntries[i].proteinName))
            specWidth.append(len(self.AllFastaEntries[i].proteinSpecies))

        idWidth=max(idWidth)+5
        nameWidth=max(nameWidth)+5
        specWidth=max(specWidth)+5
        seqWidth=max(seqWidth)+5
        spacer="|"
        id = ("Protein id").center(idWidth, " ")
        name =("Protein name").center(nameWidth, " ")
        spec =("Protein species").center(specWidth, " ")
        seq = ("Protein sequence").center(seqWidth, " ")
        line = spacer + id + spacer + name + spacer + spec + spacer + seq + spacer
        floor="+" + "-" * (idWidth) + "+" + "-" * (nameWidth) + "+"+ "-" * (specWidth) + "+" + "-"*(seqWidth)+"+"
        dataToOut += floor + "\n"
        dataToOut+=line+"\n"
        for idx in range(1, len(self.AllFastaEntries)):
            id=" "+self.AllFastaEntries[idx].proteinId.ljust(idWidth-1, " ")
            name=" "+self.AllFastaEntries[idx].proteinName.ljust(nameWidth-1, " ")
            spec=" "+self.AllFastaEntries[idx].proteinSpecies.ljust(specWidth-1, " ")
            seq=(" "+self.AllFastaEntries[idx].proteinSequence[:seqWidth-4]+"...").ljust(seqWidth, " ")
            line=spacer + id + spacer + name + spacer + spec + spacer + seq + spacer
            dataToOut += floor + "\n"
            dataToOut += line + "\n"
        dataToOut += floor + "\n"

        return dataToOut
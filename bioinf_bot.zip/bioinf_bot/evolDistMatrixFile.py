import time

class evolDistMatrix:

    def getPairwiseDistance(self, seq1, seq2):
        distance=0
        if len(seq1)!=len(seq2):
            distance+=len(seq1)-len(seq2)
        for i in range(len(seq1)):
            if seq1[i]!=seq2[i]: distance+=1
        return distance

    def createDistMatrix(self, rawData):
        distMat=[]
        for h in range(len(rawData)):
            distMat.append([])
            for w in range(len(rawData)):
                if w!=0 and h!=0: distMat[h].append(float(self.getPairwiseDistance(rawData[h], rawData[w])))
        return distMat


    def exportReport(self):
        data="Evolution distances matrix:"+"\n"
        data+=self.outStrEvolDistMatrix()
        data+="\n"
        return data

    def str2intMatrix(someMatrix):
        valMatrix=someMatrix.split("\n")
        valMatrix=[line.split(" ") for line in valMatrix]

        for line in range(len(valMatrix)):
            for val in range(len(valMatrix[line])):
                valMatrix[line][val]=float(valMatrix[line][val])
        return valMatrix

    def fillMatrix(someMatrix):
        maxHeight=len(someMatrix)
        maxWidth=max([len(line) for line in someMatrix])
        if maxWidth != maxHeight:
            print("distances matrix is not square!")
            return

        for h in range(maxHeight):
            for w in range(maxWidth):
                if h==w: someMatrix[h].append(0.000)
                if w>h: someMatrix[h].append(someMatrix[w][h-w])
        return someMatrix

    def getEvolDistMatrix(self):
        return self.distMatrix

    def outStrEvolDistMatrix(self):
        maxValPrec = 0
        valMatrix=self.distMatrix
        output=""
        for line in range(len(valMatrix)):
            for strval in range(len(valMatrix[line])):
                currLen = len(str((valMatrix[line][strval])))
                if maxValPrec < currLen: maxValPrec = currLen
        for h in range((len(valMatrix))):
            for w in range(len(valMatrix[h])):
                currVal=str(valMatrix[h][w])
                output+=currVal+"0"*(maxValPrec-len(currVal))+" "
            output+="\n"
        return output

    def __init__(self,  filename=None, rawData=None, mode=None):
        if mode=="file" and filename:
            with open(filename, "rt") as f:
                rawMatrix=f.read()
                numMatrix = evolDistMatrix.str2intMatrix(rawMatrix)
                prepMatrix = evolDistMatrix.fillMatrix(numMatrix)
        elif mode=="var" and rawData:
                prepMatrix=self.createDistMatrix(rawData)
        else:
            print("distMatrixInit: No input!")
            return

        self.distMatrix=prepMatrix





import evolDistMatrixFile
import getBioinfData
import time

class newData:

    def findMin(self, arr):
        minH=float("inf")
        minW=float("inf")
        minHArr=[]
        minWArr=[]
        for h in range(len(arr)):
            for w in range(len(arr)):
                if arr[h][w]>arr[minH][minW] and h>w:
                    minH, minW, minVal = h, w, arr[minH][minW]
        minHArr.append(minH)
        minWArr.append(minW)
        for h in range(len(arr)):
            for w in range(len(arr)):
                if arr[h][w] == minVal and h > w:
                    minHArr.append(h)
                    minWArr.append(w)

        return minHArr, minWArr

    def runUpgma(self, mode="lb"):
        distMat=self.dataDistMatrix.getEvolDistMatrix()
        leaves=[]

    def __init__(self, filename):
        self.fullData=getBioinfData.extractFromFasta(filename)
        self.dataProteinSeqs=[eachEntry.proteinSequence for eachEntry in self.fullData.AllFastaEntries]
        self.dataDistMatrix=evolDistMatrixFile.evolDistMatrix(None, self.dataProteinSeqs, "var")

    def saveReport(self, filename=None):
        data="Report at "+str(round(time.time(), 2))+"\n\n"
        data+=self.dataDistMatrix.exportReport()
        data+=self.fullData.exportReport()
        if not filename: filename="report_"
        filename+="report "+str(time.time())[:5]+".txt"
        with open(filename, "wt") as f:
            f.write(data)
        f.close()
        return filename

def getBondsForce(var1, var2):
    if var1=="A" and var2=="U": return 2
    elif var1=="U" and var2=="A": return 2
    elif var1=="G" and var2=="C": return 3
    elif var1=="C" and var2=="G": return 3
    else: return 0

def nussinov(seq):
    seqLen=len(seq)
    bondsForceMatrix=[[getBondsForce(seq[w], seq[h]) for w in range(seqLen)] for h in range(seqLen)]
    return bondsForceMatrix

def showMatrix(seq):
    seqLen = len(seq)
    size=seqLen+1
    spacer=" "
    matrix=nussinov(seq)
    for h in range(size):
        for w in range(size):
                if (h==0 and w==0) or\
                   (h==size and w==0)  or\
                   (h==size and w==0) or\
                   (h==size and w==size):
                    print("-", end=spacer)

                elif (h==0 and w!=0): print(seq[w-1], end=spacer)
                elif (h==size and w!=0): print(seq[w-1], end=spacer)
                elif (w==0 and h!=0): print(seq[h-1], end=spacer)
                elif (w==size and h!=0): print(seq[h-1], end=spacer)
                else: print(matrix[h-2][w-2], end=spacer)
        print()

def outStrMatrix(seq):
    seqLen = len(seq)
    size=seqLen+1
    spacer=" "
    data=""
    matrix=nussinov(seq)
    for h in range(size):
        for w in range(size):
                if (h==0 and w==0) or\
                   (h==size and w==0)  or\
                   (h==size and w==0) or\
                   (h==size and w==size):
                    data+="-"+spacer

                elif (h==0 and w!=0): data+=str(seq[w-1])+spacer
                elif (h==size and w!=0): data+=str(seq[w-1])+spacer
                elif (w==0 and h!=0): data+=str(seq[h-1])+spacer
                elif (w==size and h!=0): data+=str(seq[h-1])+spacer
                else: data+=str(matrix[h-2][w-2])+spacer
        data+="\n"

    return data

def writeFile(data, filename):
    with open(filename, "wt") as f:
        f.write(data)
    f.close()







import metadata
import cv2
import ascii

metadata.GetAsscii("img.png")
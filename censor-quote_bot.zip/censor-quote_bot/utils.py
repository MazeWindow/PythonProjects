import config
import requests
import numpy as np
import cv2
from PIL import Image, ImageFont, ImageDraw
import json
from random import randint as rand
from random import choice
import os
import redis

# redis create database and
# CRUD operations
def redis_create():
    try:
        client=redis.Redis()
        return client
    except Exception as e:
        print(e)
        return False

def redis_read_cases(client, user_id):
    try:
        return client.get(user_id)
    except Exception as e:
        print(e)
        return False

def redis_add_user(client, user_id):
    try:
        entry={user_id:0}
        client.set(entry)
        return True
    except Exception as e:
        print(e)
        return False

def redis_del_user(client, user_id):
    try:
        client.delete(user_id)
        return True
    except Exception as e:
        print(e)
        return False

def redis_user_add_case(client, user_id):
    try:
        cases=client.get(user_id)
        cases+=1
        client.delete(user_id)
        entry={user_id:cases}
        client.set(entry)
        return True
    except Exception as e:
        print(e)
        return False

def redis_flush(client):
    try:
        client.flushdb()
        return True
    except Exception as e:
        print(e)
        return False

def brk_rect_2_pts(arr2d): # breaks rectangles [x1, y1,  x2, y2] into
    arr2dp=[[]for i in range(len(arr2d)*2)]
    for i in range(0, len(arr2d)*2, 2):
        arr2dp[i]=[arr2d[i//2][0], arr2d[i//2][1]]
        arr2dp[i+1]=[arr2d[i//2][2], arr2d[i//2][3]]
    return arr2dp

def get_rect_bonds(arr2d):
    min_x=np.inf
    min_y=np.inf
    max_x=0
    max_y=0
    for point in arr2d:
        if point[0]>max_x: max_x=point[0]
        if point[1]>max_y: max_y=point[1]
        if point[0] < min_x: min_x = point[0]
        if point[1] < min_y: min_y = point[1]

    return min_x, min_y, max_x, max_y

def single_point_transformer(arr): #converts detectMultiscale array [x,y, width, height] into [x1,y1 x2,y2]
    return [arr[0], arr[1], arr[0]+arr[2], arr[1]+arr[3]]

def array_point_transformer(arr2d):
    for arr in range(len(arr2d)):
        arr2d[arr]=single_point_transformer(arr2d[arr])
    return arr2d

def censor_bar_from_eyes(eyes):
    print("cb0: ", eyes, "\neyes to arr2d: ")
    arr2d=eyes
    print("cb1: ", arr2d, "\ndetectmulti to rect format: ")
    arr2d = array_point_transformer(arr2d)
    print("cb2: ", arr2d, "\nbreaking rectangles: ")
    arr2d = brk_rect_2_pts(arr2d)
    print("cb3: ", arr2d, "\ngetting final bonds: ")
    arr2d = get_rect_bonds(arr2d)
    print("cb4: ", arr2d)
    print("final coords: ", arr2d)
    return arr2d

def censor_bar_from_arr2d(arr2d):
    print("cb1: ", arr2d)
    arr2d=array_point_transformer(arr2d)
    print("cb2: ", arr2d)
    arr2d=brk_rect_2_pts(arr2d)
    print("cb3: ", arr2d)
    arr2d=get_rect_bonds(arr2d)
    print("cb4: ", arr2d)
    return arr2d

def put_black_box(image_path):
    x_max, y_max, x_min, y_min=censor_meme(image_path)
    img = cv2.imread(image_path)
    #cv2.rectangle(roi_color, (x_max, y_max), (x_min, y_min), (0, 0, 0), -1)
    cv2.imshow('img', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()




def tg_download_file(link):
    url = config.SERVER_FILES_DIR + link  # url to download file from consists of path to server and path on server
    local_name = config.LOCAL_JPG_DIR+ cut_path(link)  # cutting path, getting file name
    download_file(url, local_name)  # downloading file from url into local dir
    return local_name

def cut_path(path):
    return path[path.rfind("/") + 1:]

def cut_extension(name):
    return name[:name.rfind(".")]

def get_extension(name):
    return name[name.rfind(".")+1:]

def download_file(link, filename=""):
    try:
        if filename:
            pass
        else:
            req = requests.get(link)
            filename = req.url[link.rfind("/") + 1:]

        with requests.get(link) as req:
            with open(filename, "wb") as f:
                for chunk in req.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            return filename
    except Exception as e:
        print(e)
        return None

def writefile(filename, data):
    try:
        with open(filename, "wb") as f:
            f.write(data)
            print("file saved")
    except Exception as e:
        print(e)
        return None

def readfile(filename):
    data=None
    try:
        with open(filename, "rb") as f:
            data=f.read()
            print("file read")
            return data
    except Exception as e:
        print(e)
        return None


# main processing function
def censor_meme(image_path, artist=None, font=None):
    width=config.MASK_WIDTH
    height=config.MASK_HEIGHT
    eyes_arr=[]
    face_sens=config.FACE_CASCADE_SENSIVITY
    eyes_sens=config.EYES_CASCADE_SENSIVITY
    face_cascade = cv2.CascadeClassifier("venv\Lib\site-packages\cv2\data\haarcascade_frontalface_default.xml")
    eye_cascade = cv2.CascadeClassifier("venv\Lib\site-packages\cv2\data\haarcascade_eye_tree_eyeglasses.xml")
    # save the image(i) in the same directory
    img = cv2.imread(image_path)
    print("cv2 reads: ", image_path)
    image_path = cut_path(image_path)
    img_h, img_w, channels = img.shape
    x_max = 0
    x_min = img_w-1
    y_max = 0
    y_min = img_h-1
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.29, minNeighbors=1, minSize=(int(img_w*face_sens), int(img_h*face_sens)))
    for (x, y, w, h) in faces:
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = img[y:y + h, x:x + w]
        print(type(roi_color))

        eyes = eye_cascade.detectMultiScale(roi_gray, scaleFactor=1.03, minNeighbors=2, maxSize=(int(img_w*face_sens), int(img_h*face_sens)))

        for (ex, ey, ew, eh) in eyes:
            if ex < x_min: x_min=ex
            if ex + eh > x_max: x_max=ex + ew
            if ey < y_min: y_min = ey
            if ex + eh > y_max: y_max =ey + eh
            eyes_arr.append([x+ex,y+ey,x+ex+ew,y+ey+eh])

    x_max = int(x_max + int(width * x_min))
    x_min = int(x_min - int(width * x_min))
    y_max = int(y_max + int(height * y_min))
    y_min = int(y_min - int(height * y_min))
    for (x, y, w, h) in faces:
        roi_color = img[y:y + h, x:x + w]
        cv2.rectangle(roi_color, (x_max, y_max), (x_min, y_min), (0, 0, 0), -1)
    fontpath = get_font()
    top_text, bottom_text, pac = get_quotes()
    fontsize = int(min([img_h, img_w]) / config.FONT_SIZE)

    tw_start = img_w//2-max([len(top_text), len(top_text)])*fontsize//5
    bw_start = img_w//2-max([len(bottom_text), len(bottom_text)])*fontsize//4
    th_start = config.TEXT_PADDING_UP+fontsize
    bh_start = img_h-config.TEXT_PADDING_DOWN-fontsize
    font = ImageFont.truetype(fontpath, fontsize)
    img_pil = Image.fromarray(img)
    draw = ImageDraw.Draw(img_pil)
    draw.text((tw_start, th_start), top_text, font=font, fill=(255,255, 255,1))
    draw.text((bw_start, bh_start), bottom_text+pac, font=font, fill=(255,255,255,1))
    img = np.array(img_pil)
    cv2.imwrite(config.LOCAL_JPG_DIR+image_path, img)
    return 0


def get_quotes(artist=None):
    with open(config.QUOTS_DIR, "rt", encoding="utf-8") as f:
        data=json.load(f)
    artist_names=list(data["artists"].keys())
    random_artist=artist_names[rand(0,len(artist_names))-1]
    random_quote=data["artists"][random_artist][rand(0,len(data["artists"][random_artist])-1)]
    top_text=random_quote["qt"]
    bottom_text=random_quote["qb"]
    random_pac=data["pacifiers"][rand(0, len(data["pacifiers"])-1)]
    return top_text, bottom_text, random_pac

def get_font(font=None):
    if not font: return config.FONTS_DIR+choice(os.listdir(config.FONTS_DIR))
    else: return config.FONTS_DIR+font+".ttf"
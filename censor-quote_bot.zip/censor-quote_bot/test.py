import config
import requests
import numpy as np
import cv2
from PIL import Image, ImageFont, ImageDraw
import json
from random import randint as rand
from random import choice
import os
import utils

def detect_only_eyes(image_path):
    eye_cascade = cv2.CascadeClassifier("venv\Lib\site-packages\cv2\data\haarcascade_eye_tree_eyeglasses.xml")
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    eyes = eye_cascade.detectMultiScale(gray)
    for (x, y, w, h) in eyes:
        cv2.rectangle(img, (x,y), (x+w, y+h), (255,0,0), 5)

    cv2.imshow('only eyes', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    cv2.imwrite(config.LOCAL_JPG_DIR + image_path, img)
    return


def getList(dict):
    return dict.keys()


# Driver program
dict = {1: 'Geeks', 2: 'for', 3: 'geeks'}
print(getList(dict))

with open(config.QUOTS_DIR, "rb") as f:
    artists = json.load(f)
artists = list(artists["artists"].keys())[0]
print(artists)

import config
import utils
import telebot
import os
import json

bot=telebot.TeleBot(config.TOKEN, threaded=False)
all_data={0:["font", "artist"]}
database=utils.redis_create()

@bot.message_handler(commands=["start"])
def greetings(message):
    global database
    utils.redis_add_user(database, message.chat.id)
    current_chat_id=message.chat.id
    bot.delete_message(message.chat.id, message.message_id)
    greetings_text="Hello! I am music quoting bot\n use /make to make meme"
    bot.send_message(current_chat_id, greetings_text)

@bot.message_handler(content_types=["photo"])
def image_handler(message):
    global database
    utils.redis_user_add_case(database, message.chat.id)
    print("handler online")
    global all_data
    artist, font=False, False
    print(artist, font)
    print(message.chat.id)
    if message.from_user.id in all_data:
        print("data present")
        artist=all_data[message.from_user.id][1]
        font=all_data[message.from_user.id][0]
    else:
        print("data absent")
    print(message.json["photo"][0]["file_id"])
    link=bot.get_file(message.json["photo"][0]["file_id"]).file_path
    print("link: ", link)
    local_name=utils.tg_download_file(link)
    print("local name: ", local_name)
    print(artist, font)
    if artist and font: utils.censor_meme(local_name, artist, font)
    else: utils.censor_meme(local_name)
    with open(local_name, "rb") as f:
        data=f.read()
        f.close()
    bot.send_photo(message.chat.id, data, None)
    all_data.pop(message.from_user.id, None)
    os.remove(local_name)

@bot.message_handler(commands=["make"])
def pick_font(message):
    fonts=[utils.cut_extension(utils.cut_path(font)) for font in os.listdir("fonts/")]

    fonts_str="   "
    for i in fonts:
        fonts_str+=i+"\n   "
    msg="Pick a font\n"+"Now avalible:\n"+fonts_str
    print(fonts_str)
    bot.send_message(message.chat.id, msg)
    bot.register_next_step_handler(message, pick_artist)

def pick_artist(message):
    global all_data
    all_data[message.chat.id]=[message.text, ""]
    print("font:\n     picked:", message.text, ", token:", all_data[message.chat.id][1])
    with open(config.QUOTS_DIR, "rb") as f:
        artists=json.load(f)
    artists=list(artists["artists"].keys())
    artists_str=""
    for i in artists:
        artists_str+=i+"\n"
    msg="Now pick an artist\n"+"Now avalible:\n"+artists_str
    bot.send_message(message.chat.id, msg)
    bot.register_next_step_handler(message, nice)

def nice(message):
    global all_data
    all_data[message.chat.id] = [all_data[message.chat.id][0], message.text]
    print("artist:\n     picked:",message.text, ", token:",  all_data[message.chat.id][0])
    msg = "Now send me a pic and that\'s it"
    bot.send_message(message.chat.id, msg)
    bot.register_next_step_handler(image_handler)

if __name__ == '__main__':
     bot.infinity_polling()

